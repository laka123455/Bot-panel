BOT PANEL APK - MOBILE SETUP

1) Upload the complete botpanel-apk folder contents to a new GitHub repository (not the folder itself nested inside another folder). Keep the .github/workflows/build.yml file.
2) Open GitHub repo -> Actions -> Build Bot Panel APK -> Run workflow.
3) Wait for green success. Open the completed workflow run and download the BotPanel-debug-apk artifact ZIP. Extract it on your phone; install app-debug.apk.
4) In Termux:
   pkg install python -y
   python -m pip install flask
   mkdir -p ~/myhost/bots ~/myhost/logs
5) Copy termux-backend/panel_server.py into ~/myhost/panel_server.py. If downloading from GitHub, use the raw file URL, or paste its contents into nano ~/myhost/panel_server.py.
6) Ensure the TOKEN in panel_server.py and app/src/main/assets/index.html are identical. Default demo token is change-this-local-token; change it in BOTH files before building for better local protection.
7) Put your own .py bot scripts into ~/myhost/bots. Example: cp /path/to/your_bot.py ~/myhost/bots/
8) Start backend in Termux: cd ~/myhost && python panel_server.py
9) Open Bot Panel app. Keep Termux backend running while using the app. Start/Stop/Restart works only for scripts in ~/myhost/bots.

IMPORTANT:
- Backend binds to 127.0.0.1 only; do not change it to 0.0.0.0 or expose it publicly.
- This starter app does not upload files through the APK yet; copy .py files into ~/myhost/bots with Termux file commands.
- Telegram bot tokens must stay private and must not be committed to a public GitHub repository.
- Phone/Termux is not guaranteed 24/7 hosting; Android can stop background processes.
